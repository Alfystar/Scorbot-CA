

#include "scorbot.h"



void Controllo(void)
{
 char szText[80+1];


 sprintf(szText, "Iterazione di 'Real-Time'   n.%7ld", ROBOTRealTimeCounter);
 ROBOTWriteVideoRAM(1, 12, szText);
}






main()
{
 long   loopCounter;
 int    inputOK;
 char   szText[80+1];
 double ms;

 clrscr();
 printf("Inizio programma\n");

 if (ROBOTInit(Controllo, NULL, NULL))
    {
     printf("ROBOTInit - OK\n");

     if (ROBOTPowerON())
	{
	 printf("ROBOTPowerON - OK\n");

	 ms = 10.0;
	 do {
	     clrscr();
	     printf("Periodo di Real-Time-Clock (0.5..55 ms): ");
	     ms = atof( gets(szText));
	     printf("\n");

	     if (ms < 0.5  ||  ms > 55.0)
		{
		 printf("Valore fuori range - Premi un tasto ...\n");
		 getch();

		 inputOK = 0;
		}
	       else
		{
		 inputOK = 1;
		}

	    } while(!inputOK);

	 if (ROBOTControlStart(ms))
	    {
	     gotoxy(1, 20);
	     printf("Premere ALT-B per uscire !");

	     loopCounter = 0L;
	     do {
		 gotoxy(1, 11);
		 printf("Iterazione di 'do .. while' n.%7ld", loopCounter);
		 loopCounter++;

		} while ( !ROBOTUserBreak() );

	     ROBOTControlStop();
	    }

	 ROBOTPowerOFF();
	}
    }

 printf("Fine programma\n\n");
 printf("Premi un tasto ... ");
 getch();
}

