

#include "scorbot.h"


main()
{
 int  nLink, nPulses;
 long posError;
 char szText[160+1];


 clrscr();
 printf("Inizio programma\n");

 if (ROBOTInit(NULL, NULL, NULL))
    {
     printf("ROBOTInit - OK\n");

     if (ROBOTPowerON())
	{
	 printf("ROBOTPowerON - OK\n");

	 if (ROBOTControlStart(20.0))
	    {
	     printf("ROBOTControlStart - OK\n");

	     if (ROBOTHome())
		printf("ROBOTHome - OK\n");


	     printf("Link da muovere (0..4): ");
	     nLink = atoi( gets(szText) );
	     printf("\n");

	     printf("Numero di impulsi di movimento (+/- 4000): ");
	     nPulses = atoi( gets(szText) );
	     printf("\n");

	     printf("Guadagno del controllo di default (KP): ");
	     ROBOTDefCtrlKP = atoi( gets(szText) );
	     printf("\n");

	     posError = ROBOTDefCtrlLinkMove(nLink, nPulses);
	     printf("Errore di posizione a movimento terminato: %ld impulsi\n", posError);

	     ROBOTControlStop();
	    }

	 ROBOTPowerOFF();
	}
    }

 printf("Fine programma\n\n");
 printf("Premi un tasto ... ");
 getch();
}

