

#include "scorbot.h"


main()
{
 clrscr();
 printf("Inizio programma\n");

 if (ROBOTInit(NULL, NULL, NULL))
    {
     printf("ROBOTInit - OK\n");

     if (ROBOTPowerON())
	{
	 printf("ROBOTPowerON - OK\n");

	 // if (ROBOTHome())
	    // printf("ROBOTHome - OK\n");

	 getch();

	 ROBOTPowerOFF();
	}
    }

 printf("Fine programma\n\n");
 printf("Premi un tasto ... ");
 getch();
}

