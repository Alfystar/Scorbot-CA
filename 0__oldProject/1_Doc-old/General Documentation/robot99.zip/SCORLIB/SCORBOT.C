/* Claudio MATTOCCIA - 1996 */


#include "SCORBOT.H"

#include <dos.h>
#include <math.h>



unsigned _stklen = 32000;




/*********************************************
 SCHEDA KEITHLEY DDA6

 Struttura di gestione ed indirizzo di I/O BUS
*********************************************/
DDATypeRegs  ROBOT_dda;

word dda_IOAddr = 0x300;



/**************************************************************
 PUNTATORI A FUNZIONI

 ROBOTUserControl  = Legge di Controllo;
 ROBOTErrorCheck   = Controllo fine corsa;
 ROBOTUserBreakMsg = Messaggio di 'User Break';
**************************************************************/
static void (*ROBOTUserControl) (void);
static void (*ROBOTErrorCheck)  (void);
static void (*ROBOTUserBreakMsg)(void);




/* Descrizione Stati dei Link */
const char *ROBOTMotorStateString[] = {"READY", "ERROR", "MOVEING", "STOPPED" };

/* Descrizione Nomi dei Link*/
const char *ROBOTMotorLinkString[] = {"BASE", "SHOULDER", "ELBOW", "PITCH", "ROLL", "GRIPPER" };


/* Struttura Principale di stato del robot */
ROBOTTypeMotorRecord ROBOTMotor[ ROBOT_MAX_MOTOR  ];

/* Tasto per User Break (ALT-B)*/
int ROBOTUserBreakKey = -48;

/* Gestione Real Time */
static bool   realTimeCtrlON = FALSE;
static double realTimeClock  = 50.0; /* ms */

/* Conta il numero di esecuzioni completate della funzione di real time */
volatile long ROBOTRealTimeCounter = 0L;

/* Buffer di gestione canali AUX e HOME */
int SYSAux;
int SYSHome;

/* Stati della pinza */
enum { CLOSE = 0, OPEN = 1 } ROBOTGripperStatus;

/* Variabili per la conversione imp./mm apertura pinza */
// float ROBOTGripperMaxmm       =  85.0; /* Massima apertura della pinza in millimetri */
// int   ROBOTGripperGapMaxSteps =  455;  /* Massima apertura della pinza in impulsi    */

/* Apertura attuale della pinza convertita in millimetri */
// int   ROBOTGripperGap  =  0;

/* Valore massimo per 'ROBOTMotor[n].mVolt' */
const long  ROBOTMaxmVoltValue = 5000;

/* Ampiazza di movimento per ricerca della HOME */
int   ROBOTHomePulse[ ROBOT_MAX_LINK ]   = { 4000, 2000, 3000, 3000, 3000 };


/************************************************************
 CONTROLLO ALIMENTAZIONE AMPLIFICATORI DI POTENZA

  Se TRUE le funzioni ROBOTPowerON e ROBOTPowerOFF
  sono chiamate rispettivamente all'attivazione del
  controllo e alla sua disattivazione. Questo fa si
  che quando non e` richiesto un controllo oppure il
  programma non e` in esecuzione gli amplificatori di
  potenza non sono alimentati.

  Se FALSE le funzioni suddette devono essere
  chiamate esplicitamente
************************************************************/
bool ROBOTAutoPowerCtrl = FALSE;





/**************************************************
 Variabili per le funzioni di DEFAULT
**************************************************/

/* Posizioni desiderate */
int  ROBOTDefCtrlPosReq[ ROBOT_MAX_MOTOR  ] = { 0, 0, 0, 0, 0, 0 };

/* Errore tra Posizione attuale e pos. desiderata */
long ROBOTDefCtrlPosError[ROBOT_MAX_MOTOR ];

/* Guadagno */
int  ROBOTDefCtrlKP = 200;

/* Tolleranza errore in impulsi */
int  ROBOTDefCtrlErrorTol = 1;

/* Per determinare eventuali fine corsa (Usato in 'ROBOTDefErrorFn') */
int  ROBOTDefErrorCounter[ROBOT_MAX_MOTOR ];

/* Ogni quanti cilci di RealTime viene effettuato il controllo su fine corsa */
word ROBOTDefErrorCheckRate = 5;




/**************************************************
 GESTIONE LINKs
**************************************************/

int ROBOTGetLinkEncoder(int nLink)
{
 int pos = 0;

 if (nLink < ROBOT_MAX_LINK)
    {
     switch(nLink)
      {
       /*
       case PITCH:
       pos = (-ROBOTMotor[PITCH].encoder + ROBOTMotor[ROLL].encoder) / 2;
       break;

       case ROLL:
       pos = (ROBOTMotor[PITCH].encoder + ROBOTMotor[ROLL].encoder) / 2;
       break;
       */
       default:
       pos = ROBOTMotor[nLink].encoder;
      }
    }

 return(pos);
}

int ROBOTGetLinkState(int nLink)
{
 int state = 0;

 if (nLink < ROBOT_MAX_LINK)
    {
     switch(nLink)
      {
       /*
       case PITCH:
       case  ROLL:
       if (ROBOTMotor[PITCH].state == ROBOT_STATE_ERROR ||
	   ROBOTMotor[ROLL].state  == ROBOT_STATE_ERROR)
	  {
	   state = ROBOT_STATE_ERROR;
	  }
	 else
	  {
	   if (ROBOTMotor[PITCH].state == ROBOT_STATE_MOVEING ||
	       ROBOTMotor[ROLL].state  == ROBOT_STATE_MOVEING)
	      {
	       state = ROBOT_STATE_MOVEING;
	      }
	     else
	      {
	       state = ROBOT_STATE_READY;
	      }
	  }
       break;
       */

       default:
       state = ROBOTMotor[nLink].state;
      }
    }

 return(state);
}


long ROBOTDefCtrlLinkMove(int nLink, int nPulse)
{
 long oldRealTimeCount;

 if (nLink < ROBOT_MAX_LINK)
    {
     ROBOTDefCtrlPosReq[nLink] = nPulse;

     oldRealTimeCount = ROBOTRealTimeCounter;
     do {
	 /* Just wait ... */

	}  while(!ROBOTUserBreak() && (ROBOTGetLinkState(nLink) == ROBOT_STATE_MOVEING  ||  ROBOTRealTimeCounter == oldRealTimeCount));
    }

 return( ROBOTDefCtrlPosError[nLink] );
}


/**************************************************
 GESTIONE MOTORs
**************************************************/
int ROBOTGetMotorEncoder(int nMotor)
{
 if (nMotor < ROBOT_MAX_MOTOR )
    return( ROBOTMotor[nMotor].encoder );

 return(0);
}

int ROBOTGetMotorState(int nMotor)
{
 if (nMotor < ROBOT_MAX_MOTOR )
    return( ROBOTMotor[nMotor].state );

 return(0);
}

void ROBOTSetMotorState(int nMotor, int state)
{
 if (nMotor < ROBOT_MAX_MOTOR)
    ROBOTMotor[nMotor].state = state;
}

void ROBOTSetMotorOutput(int nMotor, long mVolt)
{
 if (nMotor < ROBOT_MAX_MOTOR )
    {
     /* Controllo Saturazione DAC */
     if (mVolt > ROBOTMaxmVoltValue)
	mVolt = ROBOTMaxmVoltValue;

     if (mVolt < -ROBOTMaxmVoltValue)
	mVolt = -ROBOTMaxmVoltValue;

     ROBOTMotor[nMotor].mVolt = (int) mVolt;
    }
}

void ROBOTResetMotorError(int nMotor)
{
 if (nMotor < ROBOT_MAX_MOTOR )
    {
     ROBOTMotor[nMotor].mVolt      =  0;
     ROBOTMotor[nMotor].state      =  ROBOT_STATE_READY;
     ROBOTMotor[nMotor].oldEncoder = ~ROBOTMotor[nMotor].encoder;
    }
}


void ROBOTDefCtrlMotorStop(int nMotor)
{
 ROBOTDefCtrlPosReq[nMotor] = ROBOTMotor[nMotor].encoder;
}


long ROBOTDefCtrlMotorMove(int nMotor, int nPulse)
{
 long oldRealTimeCount;

 if (nMotor < ROBOT_MAX_MOTOR )
    {
     ROBOTDefCtrlPosReq[nMotor] = nPulse;
     oldRealTimeCount = ROBOTRealTimeCounter;

     do {
	 /* Just wait ... */

	}  while(!ROBOTUserBreak() && (ROBOTGetMotorState(nMotor) == ROBOT_STATE_MOVEING  ||  ROBOTRealTimeCounter == oldRealTimeCount));
    }

 return( ROBOTDefCtrlPosError[nMotor] );
}




/**************************************************
 FUNZIONI DI DEFAULT
**************************************************/
void ROBOTDefCtrlFn(void)
{
 register int nLink;
 int  posAttuale;
 long posError, mVolt;


 for (nLink = 0; nLink < ROBOT_MAX_LINK; nLink++)
     {
      posAttuale = ROBOTGetLinkEncoder(nLink);

      if (ROBOTGetMotorState(nLink) == ROBOT_STATE_ERROR)
	 {
	  // ROBOTResetMotorError(nLink);
	  ROBOTDefCtrlPosReq[nLink] = posAttuale;
	 }

      /* Errore in Posizione */
      posError = posAttuale - ROBOTDefCtrlPosReq[nLink];

      /* Delta di tolleranza errore in impulsi */
      if (labs(posError) < (long) ROBOTDefCtrlErrorTol)
	 posError = 0L;

      switch(nLink)
       {
	/*
	case PITCH:
	ROBOTDefCtrlPosError[PITCH] = -posError;
	ROBOTDefCtrlPosError[ROLL]  =  posError;
	break;

	case ROLL:
	ROBOTDefCtrlPosError[PITCH] += posError;
	ROBOTDefCtrlPosError[ROLL]  += posError;
	break;
	*/
	default:
	ROBOTDefCtrlPosError[nLink] = posError;
       }
     }

/****************************************************************
 Secondo ciclo necessario per caricare correttamente PITCH e ROLL
 prima di applicare i guadagni e la tenzione ai motori.
 ***************************************************************/
 for (nLink = 0; nLink < ROBOT_MAX_LINK; nLink++)
     {
      mVolt = ROBOTDefCtrlPosError[nLink] * ROBOTDefCtrlKP;

      ROBOTSetMotorOutput(nLink, mVolt);
     }
}


/********************************************************************
 Questa funzione controlla l'eventuale raggiungimento di fine corsa.

 Non avendo la struttura meccanica dello SCORBOT-ER interruttori o
 pulsanti per segnalare il raggiungimento di fine corsa, questa
 funzione osserva se il robot DOVREBBE muoversi ma non lo fa per
 un certo numero di cicli di controllo. Se tale situazione � vera
 significa che il link � arrivato ad un fine corsa.
*******************************************************************/
void ROBOTDefErrorFn(void)
{
 /*
  Per ogni motore, la condizione di errore deve essere attiva in modo continuativo
  per 'ROBOTDefErrorCheckRate'volte.

  Se e' verificata tale situazione, l'errore e' gestito azzerando la tensione
  d'uscita.
 */

 register int i;

 #ifdef _ROBOT_FLAG_CHECK
 ROBOTWriteVideoRAM(1, 1, "Error Checking");
 #endif


 for (i = 0; i < ROBOT_MAX_MOTOR; i++)
     {
      // Verifica condizione di errore
      if (ROBOTMotor[i].fcPos || ROBOTMotor[i].fcNeg)
	 {
	  // Controllo della periodicita' richiesta per gestione errore
	  ROBOTDefErrorCounter[i]++;

	  if (ROBOTDefErrorCounter[i] >= ROBOTDefErrorCheckRate)
	     {
	      ROBOTDefErrorCounter[i] = 0;

	      ROBOTSetMotorOutput(i, 0);
	      ROBOTSetMotorState(i, ROBOT_STATE_ERROR);
	     }
	 }
	else
	 {
	  // Elimina effetto cumulativo per errori non continuativi
	  ROBOTDefErrorCounter[i] = 0;

	  // Assegna Stato dei Motori
	  ROBOTSetMotorState(i, (ROBOTMotor[i].oldEncoder != ROBOTMotor[i].encoder) ? ROBOT_STATE_MOVEING : ROBOT_STATE_READY);
	 }
     }
}


void ROBOTDefUserBreakMsgFn()
{
 gotoxy(1, 24);
 // cprintf("%s%c", "User Break ! ", 7);
}


static void DefHomeFuncRT(void)
{
 /* DO NOTHING */
}





/**************************************************
 Funzioni di Interfaccia con la Libreria
**************************************************/


static void ROBOTRealTimeControlFn()
{
 register int  i;

 SYSAux   = PUReadAux(&ROBOT_dda);
 SYSHome  = PUReadHome(&ROBOT_dda);

 PULatchEncoders(&ROBOT_dda);
 for (i = 0; i < ROBOT_MAX_MOTOR; i++)
     {
      ROBOTMotor[i].oldEncoder = ROBOTMotor[i].encoder;
      ROBOTMotor[i].encoder    = -((int) PUReadEncoder(&ROBOT_dda, i+1));
      // ROBOTMotor[i].home       = FC_LEFT(SYSHome, i);
     }

 ROBOTMotor[BASE].fcPos      = FC_RIGHT(SYSAux, 4);
 ROBOTMotor[BASE].fcNeg      = FC_LEFT(SYSHome, 4);

 ROBOTMotor[SHOULDER].fcPos  = FC_RIGHT(SYSAux, 3);
 ROBOTMotor[SHOULDER].fcNeg  = FC_LEFT(SYSHome, 3);

 ROBOTMotor[ELBOW].fcPos     = FC_RIGHT(SYSAux, 2);
 ROBOTMotor[ELBOW].fcNeg     = FC_LEFT(SYSHome, 2);

 ROBOTMotor[PITCH].fcPos     = FC_RIGHT(SYSAux, 7);
 ROBOTMotor[PITCH].fcNeg     = FC_LEFT(SYSHome, 7);

 ROBOTMotor[ROLL].fcPos      = FC_RIGHT(SYSAux, 6);
 ROBOTMotor[ROLL].fcNeg      = FC_LEFT(SYSHome, 6);

 ROBOTMotor[GRIPPER].fcPos   = FC_RIGHT(SYSAux, 5);
 ROBOTMotor[GRIPPER].fcNeg   = FC_LEFT(SYSHome, 5);

 /*
  Restanti bit della prima porta (home) potrebbero essere
  usati come flags interni
 */

 ROBOTUserControl();
 ROBOTErrorCheck();

 for (i = 0; i < ROBOT_MAX_MOTOR; i++)
     {
      DDALoadDAC(&ROBOT_dda, i, ROBOTMotor[i].mVolt);
     }

 ROBOTRealTimeCounter++;
}


void ROBOTStopMotor(int nMotor)
{
 if (nMotor < ROBOT_MAX_MOTOR)
    {
     ROBOTMotor[nMotor].mVolt = 0;
     ROBOTMotor[nMotor].state = ROBOT_STATE_STOPPED;

     DDALoadDAC(&ROBOT_dda, nMotor, ROBOTMotor[nMotor].mVolt);
    }
}


void ROBOTStopMotors(void)
{
 int i;

 for (i = 0; i < ROBOT_MAX_MOTOR; i++)
     ROBOTStopMotor(i);
}


void ROBOTResetEncoders(void)
{
 int i;

 PUResetAllEncoders(&ROBOT_dda);

 for (i = 0; i < ROBOT_MAX_MOTOR; i++)
     {
      ROBOTMotor[i].encoder    = 0;
      ROBOTMotor[i].oldEncoder = ~ROBOTMotor[i].encoder;
     }
}




bool ROBOTControlStart(double ms)
{
 bool esitoOK = FALSE;

 if (!realTimeCtrlON)
    {
     if (ROBOTAutoPowerCtrl)
	{
	 if (ROBOTPowerON())
	    esitoOK = TRUE;
	}
       else
	esitoOK = TRUE;

     if (esitoOK)
	{
	 ROBOTRealTimeCounter = 0L;
	 esitoOK = RTStart(ROBOTRealTimeControlFn, ms);
	 if (esitoOK)
	    {
	     realTimeClock  = ms;
	     realTimeCtrlON = TRUE;
	    }
	}
    }

 return(esitoOK);
}


void ROBOTControlStop(void)
{
 if (realTimeCtrlON)
    {
     RTStop();
     ROBOTStopMotors();

     realTimeCtrlON = FALSE;

     if (ROBOTAutoPowerCtrl)
	ROBOTPowerOFF();
    }
}




void ROBOTSetMotorBound(int nMotor, int boundP, int boundN)
{
 if (nMotor < ROBOT_MAX_MOTOR )
    {
     ROBOTMotor[nMotor].maxPBound = boundP;
     ROBOTMotor[nMotor].maxNBound = boundN;
    }
}


void ROBOTReset(void)
{
 int  i;

 SYSAux  = PUReadAux(&ROBOT_dda);
 SYSHome = PUReadHome(&ROBOT_dda);


 ROBOTResetEncoders();
 PULatchEncoders(&ROBOT_dda);
 for (i = 0; i < ROBOT_MAX_MOTOR; i++)
     {
      ROBOTMotor[i].encoder    = -((int) PUReadEncoder(&ROBOT_dda, i+1));
      ROBOTMotor[i].oldEncoder = ~ROBOTMotor[i].encoder;

      ROBOTMotor[i].maxPBound =  32000;
      ROBOTMotor[i].maxNBound = -32000;

      ROBOTMotor[i].state = ROBOT_STATE_READY;
      ROBOTMotor[i].mVolt = 0;

      ROBOTMotor[i].home   = 0; // HOME_SWITCH_STATE(switches, i);
      ROBOTMotor[i].homeOK = FALSE;

      ROBOTDefCtrlPosReq[i]   = 0;
      ROBOTDefErrorCounter[i] = 0;
     }
}



bool ROBOTInit( void (*UserControlFunc)(void),
		void (*UserErrorCheckFunc)(void),
		void (*UserBreakMsgFunc)(void) )
{
 int esito;

 if (UserControlFunc)
    ROBOTUserControl = UserControlFunc;
   else
    ROBOTUserControl = ROBOTDefCtrlFn;


 if (UserErrorCheckFunc)
    ROBOTErrorCheck = UserErrorCheckFunc;
   else
    ROBOTErrorCheck = ROBOTDefErrorFn;


 if (UserBreakMsgFunc)
    ROBOTUserBreakMsg = UserBreakMsgFunc;
   else
    ROBOTUserBreakMsg = ROBOTDefUserBreakMsgFn;


 esito = PUInit(&ROBOT_dda, dda_IOAddr);
 ROBOTReset();

 return(esito);
}




bool ROBOTUserBreak(void)
{
 int asciiCode, scanCode, modKey;

 if (ROBOTKeyboardRead(&asciiCode, &scanCode, &modKey))
    {
     if (scanCode == ROBOTUserBreakKey)
	{
	 ROBOTStopMotors();
	 ROBOTUserBreakMsg();
	 return(TRUE);
	}
    }

 return( FALSE );
}



void ROBOTHomeLinkSetOutput(int nLink, long mVolt)
{
 if (nLink < ROBOT_MAX_LINK)
    {
     /* Controllo Saturazione DAC */
     if (mVolt > ROBOTMaxmVoltValue)
	mVolt = ROBOTMaxmVoltValue;

     if (mVolt < -ROBOTMaxmVoltValue)
	mVolt = -ROBOTMaxmVoltValue;


     ROBOTMotor[nLink].mVolt = (int) mVolt;
     /*
     if (nLink == PITCH)
	ROBOTMotor[ROLL].mVolt = -ROBOTMotor[nLink].mVolt;

     if (nLink == ROLL)
	ROBOTMotor[PITCH].mVolt = ROBOTMotor[nLink].mVolt;
     */
    }
}


bool ROBOTHomeLinkSearch(int nLink, int nPulse)
{
 bool userBreak = FALSE;

 while (!ROBOTMotor[nLink].home  &&
       (abs(ROBOTMotor[nLink].encoder) < nPulse)  &&
       (ROBOTMotor[nLink].state != ROBOT_STATE_ERROR)  &&
       (abs(ROBOTMotor[nLink].mVolt) > 0)  &&
       (!userBreak))
       {
	userBreak = ROBOTUserBreak();
       }

 return(userBreak);
}


bool ROBOTHomeLink(int nLink, int nPulse)
{
 bool userBreak = FALSE;
 int  s         = nPulse/abs(nPulse),  /* Segno degli impulsi      */
      tSearch   = 3500 * s,            /* Tensione Ricerca Switch  */
      tFast     = 5000 * s,            /* Tensione Andatura Veloce */
      tSlow     = 2000;                /* Tensione Andatura Lenta  */


 ROBOTMotor[nLink].homeOK = FALSE;

 ROBOTResetMotorError(nLink);
 ROBOTResetEncoders();


 /* Prima ricerca nella direzione richiesta */
 ROBOTHomeLinkSetOutput(nLink, -tSearch);
 ROBOTHomeLinkSearch(nLink, nPulse*s);

 if (!ROBOTMotor[nLink].home)
    {
     ROBOTResetMotorError(nLink);
     ROBOTResetEncoders();

     /* Ritorno veloce nella dirazione di partenza */
     ROBOTHomeLinkSetOutput(nLink, tFast);
     ROBOTHomeLinkSearch(nLink, nPulse*s);

     /* Tentativo in direzione opposta */
     ROBOTHomeLinkSetOutput(nLink, tSearch);
     ROBOTHomeLinkSearch(nLink, nPulse*2*s);
    }


 ROBOTStopMotors();
 if (ROBOTMotor[nLink].home)
    {
     ROBOTResetMotorError(nLink);
     ROBOTResetEncoders();

     /* Ricerca di precisione (il primo ROBOTMotor[nLink].home == FALSE */
     ROBOTHomeLinkSetOutput(nLink, tSlow);
     while (ROBOTMotor[nLink].home  &&  (!userBreak))
	   {
	    userBreak = ROBOTUserBreak();
	   }

     ROBOTStopMotors();

     if (!ROBOTMotor[nLink].home)
	ROBOTMotor[nLink].homeOK = TRUE;
    }

 return( ROBOTMotor[nLink].homeOK );
}



/*
int ROBOTGripperMove(long mVolt)
{
 int gap;

 ROBOTSetMotorOutput(GRIPPER, mVolt);

 do {
     //
    } while ((ROBOTMotor[GRIPPER].state != ROBOT_STATE_ERROR) &&
	     !ROBOTUserBreak());

 // Gap in impulsi
 gap = (ROBOTMotor[GRIPPER].encoder <= ROBOTGripperGapMaxSteps) ?
	ROBOTMotor[GRIPPER].encoder : ROBOTGripperGapMaxSteps;

 if (gap < 0)
    gap = 0;

 // Gap in millimetri
 ROBOTGripperGap = floor( ((gap * ROBOTGripperMaxmm) / (float) ROBOTGripperGapMaxSteps) + 0.49);

 ROBOTResetMotorError(GRIPPER);
 return(gap);
}
*/


int ROBOTGripperClose(void)
{
 ROBOTSetMotorOutput(GRIPPER, -4000);
 ROBOTGripperStatus = CLOSE;

 return 0;
}

int ROBOTGripperOpen(void)
{
 ROBOTSetMotorOutput(GRIPPER, 4000);
 ROBOTGripperStatus = OPEN;

 return 0;
}


bool ROBOTHome(void)
{
  int  bAllMotorReady, i;
  long lOldCounter = ROBOTRealTimeCounter;

  // Invia tutti i link a fine corsa
  // (5000 � una posizione sicuramente non raggiungibile)
  ROBOTDefCtrlPosReq[BASE]     =  5000;
  ROBOTDefCtrlPosReq[SHOULDER] =  5000;
  ROBOTDefCtrlPosReq[ELBOW]    = -5000;
  ROBOTDefCtrlPosReq[PITCH]    =  5000;
  ROBOTDefCtrlPosReq[ROLL]     =  5000;


  ROBOTGripperOpen();

  do {
      // Tutti i motori devono essere READY per terminare la funzione
      bAllMotorReady = 1;
      for (i = 0; i < ROBOT_MAX_LINK && bAllMotorReady; i++)
	  if (ROBOTMotor[i].state != ROBOT_STATE_READY)
	     {
	      bAllMotorReady = 0;
	     }

       // Lo stato dei motori non viene considerato se non sono compiuti almeno 2 cicli di controllo.
       // (Ritardo necessario per sincronizzare la valutazione delle variabili
       //  dopo il loro aggiornamento da parte del RealTime).
       if (abs(ROBOTRealTimeCounter-lOldCounter) < 2)
	  bAllMotorReady = 0;

     } while (!bAllMotorReady   &&  !ROBOTUserBreak());


  ROBOTReset();
  ROBOTDefCtrlPosReq[0] = -1000;
  ROBOTDefCtrlPosReq[1] =  -350;
  ROBOTDefCtrlPosReq[2] =   700;
  ROBOTDefCtrlPosReq[3] =  -790;
  ROBOTDefCtrlPosReq[4] =  -300;

  ROBOTGripperClose();

  return bAllMotorReady;
}


bool ROBOTPowerON(void)
{
 PUPowerEnable(&ROBOT_dda, ON);
 return( PUIsPowerOn(&ROBOT_dda) );
}


bool ROBOTPowerOFF(void)
{
 PUPowerEnable(&ROBOT_dda, OFF);
 return( !PUIsPowerOn(&ROBOT_dda) );
}


bool ROBOTPowerIsON(void)
{
 return( PUIsPowerOn(&ROBOT_dda) );
}



/***********************************************************
***                                                      ***
***      Utilita`:  Gestione Tastiera (Peek);            ***
***		    Video IO anche da interrupt.         ***
***                                                      ***
***********************************************************/
int ROBOTKeyboardRead(int *asciiCode, int *scanCode, int *fgModKey)
{
 int  b;
 word c;

 *asciiCode   = 0;
 *scanCode    = 0;
 *fgModKey    = 0;

 /* Controlla se � stato premuto un tasto */
 b = bioskey(1);
 if (b)
    {
     /* Legge il tasto premuto */
     c = bioskey(0);

     /* Codice ASCII */
     *asciiCode  =  c & 0x00FF;

     if (*asciiCode == 0)
	{
	 /* Codice di scansione (Tasti speciali) */
	 *scanCode =  -((c & 0xFF00) >> 8);
	}
    }

 *fgModKey = bioskey(2);

 return(b);
}


void ROBOTWriteVideoRAM(int x, int y, char *szText)
{
 char *video = MK_FP(0xB800, ((y-1)*160) + (x-1));
 int i;

 for (i = 0; i < strlen(szText); i++)
     video[i*2 + 0] = szText[i];
}





