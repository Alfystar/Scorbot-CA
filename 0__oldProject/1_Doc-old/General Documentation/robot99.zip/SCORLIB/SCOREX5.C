
#include "scorbot.h"



void Controllo(void)
{
 register int nLink;
 int  posAttuale;
 long posError, mVolt;

 for (nLink = 0; nLink < ROBOT_MAX_LINK; nLink++)
     {
      posAttuale = ROBOTGetLinkEncoder(nLink);

      if (ROBOTGetMotorState(nLink) == ROBOT_STATE_ERROR)
	 {
	  ROBOTResetMotorError(nLink);
	  ROBOTDefCtrlPosReq[nLink] = posAttuale;
	 }

      /* Errore in Posizione */
      posError = posAttuale - ROBOTDefCtrlPosReq[nLink];

      /* Delta di tolleranza errore in impulsi */
      if (labs(posError) < (long) ROBOTDefCtrlErrorTol)
	 posError = 0L;

      switch(nLink)
       {
	case PITCH:
	ROBOTDefCtrlPosError[PITCH] = -posError;
	ROBOTDefCtrlPosError[ROLL]  =  posError;
	break;

	case ROLL: /* NOTARE '+=' */
	ROBOTDefCtrlPosError[PITCH] += posError;
	ROBOTDefCtrlPosError[ROLL]  += posError;
	break;

	default:
	ROBOTDefCtrlPosError[nLink] = posError;
       }
     }


/********************************************************
 Il secondo ciclo necessario per caricare correttamente
 PITCH e ROLL prima di applicare i guadagni e la tensione
 ai motori.
 ********************************************************/

 for (nLink = 0; nLink < ROBOT_MAX_LINK; nLink++)
     {
      mVolt = ROBOTDefCtrlPosError[nLink] * ROBOTDefCtrlKP;
      ROBOTSetMotorOutput(nLink, mVolt);
     }
}



void CommandLoop()
{
 int nLink, k, f, step;


 gotoxy(1, 20);
 printf("Premere ESC per uscire !");

 step  = 70;
 nLink = 0; /* BASE */
 do {
     gotoxy(1, 21);
     printf("[1..5]Link [+ -]Movimento [H]Home [ESC]Uscita");

     ROBOTKeyboardRead(&k, &f);
     switch(k)
      {
       case '1':  /* BASE */
       case '2':  /* SHOULDER */
       case '3':  /* ELBOW */
       case '4':  /* PITCH */
       case '5':  /* ROLL */
       nLink = k - '1';
       break;

       case 'h':
       case 'H':
       ROBOTHome();
       break;

       case '+':
       ROBOTDefCtrlPosReq[nLink] += step;
       break;

       case '-':
       ROBOTDefCtrlPosReq[nLink] -= step;
       break;
      }
    } while (k != 27); /* 27 = ESC */
}



void main()
{
 clrscr();
 gotoxy(1, 3);
 printf("Inizio programma\n");

 if (ROBOTInit(Controllo, NULL, NULL))
    {
     printf("ROBOTInit - OK\n");

     if (ROBOTPowerON())
	{
	 printf("ROBOTPowerON - OK\n");

	 if (ROBOTControlStart(20.0))
	    {
           printf("ROBOTControlStart - OK\n");

           CommandLoop();

	     ROBOTControlStop();
	    }

	 ROBOTPowerOFF();
	}

    }

 printf("\nFine programma\n\nPremi un tasto ...");
 getch();
}

