

#include "scorbot.h"


void Controllo(void)
{
 register int nLink;
 int  posAttuale;
 long posError, mVolt;

 for (nLink = 0; nLink < ROBOT_MAX_LINK; nLink++)
     {
      posAttuale = ROBOTGetLinkEncoder(nLink);

      if (ROBOTGetMotorState(nLink) == ROBOT_STATE_ERROR)
	 {
	  ROBOTResetMotorError(nLink);
	  ROBOTDefCtrlPosReq[nLink] = posAttuale;
	 }

      /* Errore in Posizione */
      posError = posAttuale - ROBOTDefCtrlPosReq[nLink];

      /* Delta di tolleranza errore in impulsi */
      if (labs(posError) < (long) ROBOTDefCtrlErrorTol)
	 posError = 0L;


      /* Non linearit� */
      if (abs(posError) > 60)
	 posError = posError * 200;


      switch(nLink)
       {
	case PITCH:
	ROBOTDefCtrlPosError[PITCH] = -posError;
	ROBOTDefCtrlPosError[ROLL]  =  posError;
	break;

	case ROLL: /* NOTARE '+=' */
	ROBOTDefCtrlPosError[PITCH] += posError;
	ROBOTDefCtrlPosError[ROLL]  += posError;
	break;

	default:
	ROBOTDefCtrlPosError[nLink] = posError;
       }
     }

 /****************************************************************
  Secondo ciclo necessario per caricare correttamente PITCH e ROLL
  prima di applicare i guadagni e la tenzione ai motori.
  ***************************************************************/
 for (nLink = 0; nLink < ROBOT_MAX_LINK; nLink++)
     {
      mVolt = ROBOTDefCtrlPosError[nLink] * ROBOTDefCtrlKP;

      ROBOTSetMotorOutput(nLink, mVolt);
     }
}



main()
{
 clrscr();
 printf("Inizio programma\n");

 if (ROBOTInit(Controllo, NULL, NULL))
    {
     printf("ROBOTInit - OK\n");

     if (ROBOTPowerON())
	{
	 ROBOTDemoLoop();
	 ROBOTPowerOFF();
	}
    }

 printf("Fine programma\n\n");
 printf("Premi un tasto ... ");
 getch();
}

