// Claudio MATTOCCIA - Rev. Agosto 1998

#include "SCORB.H"


int debugLevel = 10;



// Colore di primo piano
int ikHeader      = 0,
    ikFooter1     = 4,
    ikFooter2     = 0,
    ikFooter3     = 0,
    ikMotorData   = 3,
    ikSysData     = 3,
    ikTableHeader = 15,
    ikInput       = 1,
    ikScreen      = 7;

// Colore di fondo
int bkHeader      = 7,
    bkFooter1     = 7,
    bkFooter2     = 7,
    bkFooter3     = 7,
    bkInput       = 7,
    bkScreen      = 0;




void DrawBackground(void)
{
 textbackground(bkScreen);
 textcolor(ikScreen);
 clrscr();

 textbackground(bkHeader);
 gotoxy(1, 1);
 cprintf("%80.80s", "");

 textbackground(bkFooter1);
 gotoxy(1, 22);
 cprintf("%80.80s", "");

 textbackground(bkFooter2);
 gotoxy(1, 23);
 cprintf("%80.80s", "");

 textbackground(bkFooter3);
 gotoxy(1, 24);
 cprintf("%80.80s", "");
}


void DrawHeader(char *szText)
{
 textbackground(bkHeader);
 textcolor(ikHeader);

 gotoxy(1, 1);
 cprintf(szText);
}


void DrawFooter1(char *szText)
{
 textbackground(bkFooter1);
 textcolor(ikFooter1);

 gotoxy(1, 22);
 cprintf(szText);
}


void DrawFooter2(char *szText)
{
 textbackground(bkFooter2);
 textcolor(ikFooter2);

 gotoxy(1, 23);
 cprintf(szText);
}


void DrawFooter3(char *szText)
{
 textbackground(bkFooter3);
 textcolor(ikFooter3);

 gotoxy(1, 24);
 cprintf(szText);
}


void DrawInputArea(void)
{
 int i;

 textbackground(bkInput);
 textcolor(ikInput);

 gotoxy(1, 22);
 cprintf("%80.80s", "");
 gotoxy(1, 23);
 cprintf("%80.80s", "");
 gotoxy(1, 24);
 cprintf("%80.80s", "");

 gotoxy(1, 22);
 for (i = 0; i < 80; i++)
     cprintf("_");

 gotoxy(1, 24);
 cprintf("[ENTER]Conferma");
}


void ClearInputArea(void)
{
 textbackground(bkFooter1);
 gotoxy(1, 22);
 cprintf("%80.80s", "");

 textbackground(bkFooter2);
 gotoxy(1, 23);
 cprintf("%80.80s", "");

 textbackground(bkFooter3);
 gotoxy(1, 24);
 cprintf("%80.80s", "");
}



int InputIntegerValue(char *szPrompt)
{
 char szInput[80+1];

 DrawInputArea();

 gotoxy(1, 23);
 cprintf(szPrompt);
 cprintf(" > ");

 gotoxy(strlen(szPrompt) + 4, 23);
 gets(szInput);

 ClearInputArea();

 return atoi(szInput);
}


double InputDoubleValue(char *szPrompt)
{
 char szInput[80+1];

 DrawInputArea();

 gotoxy(1, 23);
 cprintf(szPrompt);
 cprintf(" > ");

 gotoxy(strlen(szPrompt) + 4, 23);
 gets(szInput);

 ClearInputArea();

 return atof(szInput);
}



void DemoLoop(void)
{
 int kbKey, kbFunc, kbModKey;
 int i, nMotor = 0;
 int iStep = 3;

 double rtT = 30.0;



 ROBOTControlStop();
 if (ROBOTControlStart(rtT))
    {
     do {
	 textbackground(bkScreen);
	 textcolor(ikScreen);

	 gotoxy(1, 3);
	 textcolor(ikScreen);
	 cprintf("%9.9s %13.13s %5.5s %4.4s\n\r",
		 "Interrupt", "RealTimeClock", "Passo", "Kp");
	 cprintf("-------------------------------------------------------------------------------\n\r");

	 textcolor(ikSysData);
	 cprintf("%9ld %13.3lf %5d %4d",
		 RTIntCnt, rtT, iStep, ROBOTDefCtrlKP);

	 gotoxy(1, 9);
	 textcolor(ikScreen);
	 cprintf("%4.4s %6.6s %5.5s %10.10s %7.7s %7.7s %4.4s %5.5s\n\r",
		 "Sel.", "Motore", "mVolt", "Stato", "Encoder", "Errore", "Home", "Switch");
	 cprintf("-------------------------------------------------------------------------------\n\r");

	 textcolor(ikMotorData);
	 for (i = 0; i < ROBOT_MAX_MOTOR; i++)
	     cprintf("%4.4s %6d %5d %10.10s %7d %7ld %4.4s %5.5s\n\r",
		      (nMotor == i) ? ">" : " ",
		      i,
		      ROBOTMotor[i].mVolt,
		      ROBOTMotorStateString[ ROBOTMotor[i].state ],
		      ROBOTMotor[i].encoder,
		      ROBOTDefCtrlPosError[i],
		      (ROBOTMotor[i].homeOK)    ? "#" : "-",
		      (ROBOTMotor[i].home)  ? "#" : "-");


	 DrawFooter1("[ALT-B]Stop [ENTER]Reset");
	 DrawFooter2("[SHIFTS]Movimento [1]Base [2]Shoulder [3]Elbow [4]Pitch [5]Roll");
	 DrawFooter3("[HOME]Home [F1]Spedizione [F2]Kp [F3]RTClock [O/C]Pinza [+/-]Passo [ESC]Uscita");

	 if (RTOverRunError)
	    {
	     DrawFooter1("ERRORE di Over Run !");
	     RTOverRunErrorACK();
	     getch();
	    }

	 ROBOTKeyboardRead(&kbKey, &kbFunc, &kbModKey);

	 if (ROBOTUserBreak())
	    {
	     for (i = 0; i < ROBOT_MAX_LINK; i++)
		 ROBOTDefCtrlPosReq[i] = ROBOTMotor[i].encoder;
	    }

	 switch(kbKey)
	  {
	   case '1':
	   case '2':
	   case '3':
	   case '4':
	   case '5':
	   case '6':
	   nMotor = kbKey - 49;
	   break;

	   case '+':
	   if (iStep < 100)
	      iStep++;
	   break;

	   case '-':
	   if (iStep > 1)
	      iStep--;
	   break;

	   case 'o':
	   case 'O':
	   ROBOTGripperOpen();
	   break;

	   case 'c':
	   case 'C':
	   ROBOTGripperClose();
	   break;

	   case 13: /* ENTER */
	   ROBOTReset();
	   break;
	  }

	// Movimento motore con tasti SHIFT
	if (nMotor != -1)
	   if (ROBOTGetMotorState(nMotor) != ROBOT_STATE_ERROR)
	      {
	       if (kbModKey & MODKEY_LEFTSHIFT)
		  ROBOTDefCtrlPosReq[nMotor] += iStep;

	       if (kbModKey & MODKEY_RIGHTSHIFT)
		  ROBOTDefCtrlPosReq[nMotor] -= iStep;
	      }

	 switch(-kbFunc)
	  {
	   case 71: /* HOME */
	   ROBOTHome();
	   break;

	   case 59:  // F3
	   ROBOTDefCtrlPosReq[nMotor] = InputIntegerValue("Posizione richiesta per il motore selezionato");
	   break;

	   case 60:  // F2
	   ROBOTDefCtrlKP = InputIntegerValue("Guadagno del controllo (Kp)");
	   break;

	   case 61:  // F3
	   rtT = InputDoubleValue("Periodo di RealTimeClock (ms)");

	   ROBOTControlStop();
	   if (!ROBOTControlStart(rtT))
	      {
	       rtT = 30.0;
	       ROBOTControlStart(rtT);
	      }
	   break;
	  }

	 } while (kbKey != 27);

     ROBOTControlStop();
    }
}




void main()
{
 // Preparazione FrontEnd
 DrawBackground();
 DrawHeader(" Universit� degli Studi di Roma \"Tor Vergata\" - Lab. Robotica - 1999");
 DrawFooter3(" Determinazione tempi di colloquio PC <-> Power Unit, Attendere prego ...");

 ROBOTAutoPowerCtrl = FALSE;

 if (ROBOTInit(NULL, NULL, NULL))
    {
     if (ROBOTPowerON())
	{
	 DemoLoop();
	}
       else
	{
	 printf("Problemi al POWER ON\n");
	 getch();
	}

     ROBOTPowerOFF();
    }
}
