/*************************************************************************
***                                                                    ***
***                                PU.CPP                              ***
***                                                                    ***
***                          MATTOCCIA Claudio                         ***
***                                                                    ***
***                               15/07/94                             ***
***                                                                    ***
***                                                                    ***
**************************************************************************
***                                                                    ***
***               Gestione (P)ower (U)nit per SCORBOT-ER               ***
***                                                                    ***
*************************************************************************/

#include "pu.h"

/* Da definire altrove */
int pu_debug = 0;



/* Gestione dinamica del ritardo nei tempi di risposta di PU */

static word HWDelay = 0;

word ForDelay(word nDelay);
#define HW_DELAY  ForDelay(HWDelay)






word ForDelay(word nDelay)
{
 word i, v;

 v = 0;
 for (i = 0; i < nDelay; i++)
     v++;

 return(v);
}



byte PUReadHome(DDATypeRegs *dda)
{
 byte v;

 DDAWritePortA(dda, 0xFD);
 v = DDAReadPortB(dda);

 DDAWritePortA(dda, 0xFF);
 return(v);
}


byte PUReadAux(DDATypeRegs *dda)
{
 byte v;

 DDAWritePortA(dda, 0xFE);
 v = DDAReadPortB(dda);

 DDAWritePortA(dda, 0xFF);

 return(v);
}


void PUResetAllEncoders(DDATypeRegs *dda)
{
 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_OUTPUT, DDA_PORT_INPUT);
 DDAWritePortB(dda, CMD_RESET_ALL_ENCODERS);
 DDAWritePortA(dda, 0x8B);

 HW_DELAY;
 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_INPUT, DDA_PORT_INPUT);
}


void PUResetEncoderX(DDATypeRegs *dda, int nEncoder)
{
 byte cmd = 0x8B;

 cmd |= (nEncoder << 4);

 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_OUTPUT, DDA_PORT_INPUT);
 DDAWritePortB(dda, CMD_RESET_ENCODER);
 DDAWritePortA(dda, cmd);

 HW_DELAY;
 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_INPUT, DDA_PORT_INPUT);
}


void PULatchEncoders(DDATypeRegs *dda)
{
 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_OUTPUT, DDA_PORT_INPUT);
 DDAWritePortB(dda, CMD_LATCH_ENCODERS);
 DDAWritePortA(dda, 0x8B);

 HW_DELAY;
 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_INPUT, DDA_PORT_INPUT);
}


void PUPowerEnable(DDATypeRegs *dda, int status)
{
 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_OUTPUT, DDA_PORT_INPUT);

 if (status == 1) DDAWritePortB(dda, CMD_POWER_ON);
	     else DDAWritePortB(dda, CMD_POWER_OFF);

 DDAWritePortA(dda, 0x8B);

 HW_DELAY;
 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_INPUT, DDA_PORT_INPUT);
}


word PUReadEncoder(DDATypeRegs *dda, int nEncoder)
{
 word h, l;
 byte cmd;


 cmd = 0x8F;
 cmd |= (nEncoder << 4);
 DDAWritePortA(dda, cmd);
 HW_DELAY;

 h = DDAReadPortB(dda);

 cmd = 0x87;
 cmd |= (nEncoder << 4);
 DDAWritePortA(dda, cmd);
 HW_DELAY;

 l = DDAReadPortB(dda);

 DDAWritePortA(dda, 0xFF);
 HW_DELAY;

 return(l + (h << 8));
}


int PUReadEncoders(DDATypeRegs *dda, word *arEncoder, int nEncoder)
{
 int i;

 PULatchEncoders(dda);

 for (i = 0; i < nEncoder  &&  i < 6; i++)
     arEncoder[i] = PUReadEncoder(dda, i+1);

 return(i);
}



byte PUReadStatus(DDATypeRegs *dda)
{
 byte cmd, res;

 cmd = 0x8F;
 DDAWritePortA(dda, cmd);

 HW_DELAY;
 res = DDAReadPortB(dda);

 DDAWritePortA(dda, 0xFF);

 return(res);
}


int PUIsPowerOn(DDATypeRegs *dda)
{
 byte b;

 b = PUReadStatus(dda);
 return( (b >> 6) & 1);
}



word PUCountDelay(DDATypeRegs *dda)
{
 byte newStatus, oldStatus;
 word i, maxDelay, oldDelay, v;


 maxDelay = 0xFFFE;
 oldDelay = maxDelay;
 do {
     // Reset All Encoders
     DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_OUTPUT, DDA_PORT_INPUT);
     DDAWritePortB(dda, CMD_RESET_ALL_ENCODERS);
     DDAWritePortA(dda, 0x8B);

     delay(1);
     DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_INPUT, DDA_PORT_INPUT);
     delay(1);

     v = 0;

     // Read Status
     DDAWritePortA(dda, 0x8F);
     delay(1);
     oldStatus = DDAReadPortB(dda);

     for (i = 0; i < maxDelay; i++)
	 v++;

     DDAWritePortA(dda, 0xFF);
     for (i = 0; i < maxDelay; i++)
	 v++;

     // Read Status
     DDAWritePortA(dda, 0x8F);
     delay(1);
     newStatus = DDAReadPortB(dda);
     delay(1);

     if (oldStatus != newStatus)
	{
	 if (maxDelay > 1)
	    {
	     oldDelay = maxDelay;
	     maxDelay /= 2;
	    }
	   else
	    return(1);
	}
       else
	return(oldDelay);

    } while(1);
}




int PUTestDelay(DDATypeRegs *dda, word testDelay)
{
 byte newStatus, oldStatus;
 int  a, b;

 PUResetAllEncoders(dda);
 ForDelay(testDelay);

 oldStatus = PUReadStatus(dda);
 ForDelay(testDelay);

// DDAWritePortA(dda, 0xFF);
// ForDelay(testDelay);

 newStatus = PUReadStatus(dda);
 ForDelay(testDelay);

 a = (oldStatus & 0x80) >> 7;
 b = (newStatus & 0x80) >> 7;

 if (pu_debug > 0)
    printf("Old Status: %0X (%d)  New Status: %0X  (%d)\n",
	    oldStatus, a, newStatus, b);

 return(a == 0  &&  b == 1);
}



int PUInit(DDATypeRegs *dda, word boardBaseAddr)
{
 int  i;
 word w;


 DDAInit(dda, boardBaseAddr);
 DDASetModePort(dda, DDA_PORT_OUTPUT, DDA_PORT_INPUT, DDA_PORT_INPUT);
 DDAInitDAC(dda, -5000, 5000);
 DDALoadDAC(dda, 0, 0);

 DDAWritePortA(dda, 0xFF);

 /*
 if (pu_debug > 0)
    printf("Init DONE\n");
 */

 HWDelay = 0;
 for (i = 0; i < 10; i++)
     {
      w = PUCountDelay(dda);
      if (w > HWDelay) HWDelay = w;
     }

 /*
 if (pu_debug > 0)
    printf("DELAY = %u\n", HWDelay);
 */

 HWDelay *= 2;
 return( PUTestDelay(dda, HWDelay) );
}





void PUDemoTest(DDATypeRegs *dda, word boardBaseAddr)
{
 int  v, e[10], k, s, h, a, motorSel;

 v = PUInit(dda, boardBaseAddr);
 printf("Esito init: %d\n", v);
 getch();

 clrscr();
 motorSel = 1;
 v = 0;
 do {
     PUReadEncoders(dda, (word *) e, 6);

     h = PUReadHome(dda);
     a = PUReadAux(dda);

     gotoxy(1, 1);
     printf("ENCODERS   -   1      2      3      4      5      6   -   HOME   -   AUX\n");
     printf("               %06d %06d %06d %06d %06d %06d  %0X         %0X\n",
	    e[0],  e[1], e[2], e[3], e[4], e[5], h, a);
     printf("\nMOTORE: %d  VOLT: %6d", motorSel, v);

     if (kbhit())
	{
	 k = getch();

	 switch(k)
	  {
	   case 'q': return;

	   case 'x': PUPowerEnable(dda, 1);
		     break;

	   case 'y': PUPowerEnable(dda, 0);
		     break;

	   case 'h': s = PUReadHome(dda);
		     printf("Home: %02X ", s);
		     getch();
		     break;

	   case 'a': s = PUReadAux(dda);
		     printf("Aux: %02X  ", s);
		     getch();
		     break;

	   case 's': s = PUReadStatus(dda);
		     printf("Status: %02X  -  Premi un tasto\n", s);
		     getch();
		     break;

	   case '1':
	   case '2':
	   case '3':
	   case '4':
	   case '5':
	   case '6': motorSel = k - 48;
		     break;

	   case 't': PUResetEncoderX(dda, motorSel);
		     break;

	   case 'r': PUResetAllEncoders(dda);
		     break;

	   case '+': if (v < 5000) v += 100;
		     DDALoadDAC(dda, motorSel-1, v);
		     break;

	   case '-': if (v > -5000) v -= 100;
		     DDALoadDAC(dda, motorSel-1, v);
		     break;
	  }
	}

    } while (1);
}




