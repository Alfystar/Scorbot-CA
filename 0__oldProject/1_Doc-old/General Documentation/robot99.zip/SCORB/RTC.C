/*************************************************************************
***                                                                    ***
***                                                                    ***
***                         MATTOCCIA Claudio                          ***
***                                                                    ***
***                              28/04/93                              ***
***                                                                    ***
***                                                                    ***
***                                                                    ***
**************************************************************************
***                                                                    ***
***                                                                    ***
***                                                                    ***
*************************************************************************/

#include "rtc.h"




/**************************************************************
***                                                         ***
***                   Variabili Condivisibili               ***
***                                                         ***
**************************************************************/

int RTIrqN      = 0x00,        /* Linea fisica di Interrupt */
    RTIntrN     = 0x08,        /* Numero di Interrupt       */
    RTInIntFlag = 0;           /* Semaforo di int. in elab. */

/* Contatore progressivo Int.*/
volatile unsigned long RTIntCnt = 0L;

/* ISR troppo lunga */
boolean RTOverRunError = FALSE;


/*************************************************************************
***                                                                    ***
***                     Variabili Non Condivisibili                    ***
***                                                                    ***
*************************************************************************/

static double  RTSystemTimerCLK = 1193.18;  /* KHz da PC = 838.1 ns     */
static boolean RTResetTimer     = FALSE;    /* Timer riprogrammato o no */

static void interrupt (*oldIntrVect)(void); /* Vecchia funzione di Int. */
static void (*RTUserFunc)(void);            /* Nuova funzione di Int.   */
static bool realTimeON = FALSE;             /* RealTime Attivato        */



/********************************************************
***                                                   ***
***                Gestione Interruzioni              ***
***                                                   ***
********************************************************/

void Intr8259AEnable(byte irq)
{
 byte oldData;

 disable();
 oldData = inportb(0x21);
 outportb(0x21, oldData &  ~(1 << irq));
 enable();
}


void Intr8259ADisable(byte irq)
{
 byte oldData;

 disable();
 oldData = inportb(0x21);
 outportb(0x21, oldData | (1 << irq));
 enable();
}


void interrupt RTIntrServiceRoutine()
{
 enable();
 oldIntrVect();

 if (!RTInIntFlag)
    {
     RTInIntFlag = 1;
     RTIntCnt++;

     RTUserFunc();

     RTInIntFlag = 0;
    }
   else RTOverRunError = TRUE;

 outportb(0x20, 0x20);
}


void RTOverRunErrorACK(void)
{
 RTOverRunError = FALSE;
 RTInIntFlag    = 0;
}



void RTLoadCounter(word value, byte mode, byte bcd)
{
 byte modeCnt = 0;

 word modeReg = 0x0043,
      dataReg = 0x0040;

 modeCnt |= 0x30;
 modeCnt |= mode << 1;
 modeCnt |= bcd;

 outportb(modeReg,  modeCnt);
 outportb(dataReg,  value & 0x00FF);
 outportb(dataReg, (value & 0xFF00) >> 8);
}



boolean RTStart(void (*funcRT)(void), double ms)
{
 word  w;

 if (!realTimeON)
    {
     outportb(0x20, 0x20);  /* Reset di eventuali interrupt non serviti */

     RTUserFunc = funcRT;
     if (RTUserFunc != NULL)
        {
         Intr8259ADisable(RTIrqN);

         if (ms > 0.0  && (ms*RTSystemTimerCLK) <= 0xFFFF)
            {
             RTResetTimer = TRUE;

             w = (word) (ms*RTSystemTimerCLK);
             RTLoadCounter(w, 2, 0);
            }
           else w = 0xFFFF;

         oldIntrVect = getvect(RTIntrN);
         setvect(RTIntrN, RTIntrServiceRoutine);
         Intr8259AEnable(RTIrqN);

         realTimeON = TRUE;
         return( TRUE );
        }
    }

 return( FALSE );
}


void RTStop(void)
{
 if (realTimeON)
    {
     Intr8259ADisable(RTIrqN);
     setvect(RTIntrN, oldIntrVect);

     if (RTResetTimer)
        {
         RTResetTimer = FALSE;
         RTLoadCounter(0xFFFF, 2, 0);
        }

     Intr8259AEnable(RTIrqN);
     RTUserFunc = NULL;
     realTimeON = FALSE;
    }
}


