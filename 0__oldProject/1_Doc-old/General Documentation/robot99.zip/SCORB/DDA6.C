/*************************************************************************
***                                                                    ***
***                                                                    ***
***                         MATTOCCIA Claudio                          ***
***                                                                    ***
***                            07/02/1993                              ***
***                                                                    ***
***                                                                    ***
***                                                                    ***
***                                                                    ***
***                                                                    ***
***                                                                    ***
**************************************************************************
***                                                                    ***
***                                                                    ***
***                                                                    ***
*************************************************************************/


#include "DDA6.H"



void DDAInit(DDATypeRegs *dda, word boardBaseAddr)
{
 int i;

 dda->baseAddr   =  boardBaseAddr;
 dda->dac0L      =  dda->baseAddr+0;
 dda->dac0H      =  dda->baseAddr+1;
 dda->dac1L      =  dda->baseAddr+2;
 dda->dac1H      =  dda->baseAddr+3;
 dda->dac2L      =  dda->baseAddr+4;
 dda->dac2H      =  dda->baseAddr+5;
 dda->dac3L      =  dda->baseAddr+6;
 dda->dac3H      =  dda->baseAddr+7;
 dda->dac4L      =  dda->baseAddr+8;
 dda->dac4H      =  dda->baseAddr+9;
 dda->dac5L      =  dda->baseAddr+10;
 dda->dac5H      =  dda->baseAddr+11;
 dda->RegIOA     =  dda->baseAddr+12;
 dda->RegIOB     =  dda->baseAddr+13;
 dda->RegIOC     =  dda->baseAddr+14;
 dda->RegIOMode  =  dda->baseAddr+15;

 dda->bitsPortA  = 0;
 dda->bitsPortB  = 0;
 dda->bitsPortC  = 0;


 /*********************************
 ***                            ***
 ***      Port A = INPUT;       ***
 ***      Port B = INPUT;       ***
 ***      Port C = OUTPUT;      ***
 ***                            ***
 *********************************/

 DDASetModePort(dda, DDA_PORT_INPUT, DDA_PORT_INPUT, DDA_PORT_OUTPUT);
 DDAWritePortC(dda, 0);

 DDAInitDAC(dda, -5000, 5000);

 for (i = 0; i < 6; i++)
     DDALoadDAC(dda, i, 0);
}



/**********************************************************
***                                                     ***
***                     Gestione DAC                    ***
***                                                     ***
**********************************************************/

void DDAInitDAC(DDATypeRegs *dda, int mVoltMin, int mVoltMax)
{
 if (mVoltMax >  10000) mVoltMax =  10000;
 if (mVoltMin < -10000) mVoltMin = -10000;

 dda->mVoltMax = mVoltMax;
 dda->mVoltMin = mVoltMin;

 if (mVoltMax == 10000) dda->realVoltMax = 9995;
 if (mVoltMax ==  5000) dda->realVoltMax = 4998;
}


void DDALoadDAC(DDATypeRegs *dda, byte nDac, int mVolt)
{
 word digCode;


 mVolt = (mVolt > dda->realVoltMax) ? dda->realVoltMax : mVolt;
 mVolt = (mVolt < dda->mVoltMin) ? dda->mVoltMin : mVolt;

 digCode = (word) ((mVolt - dda->mVoltMin) * (40960000L / (dda->mVoltMax - dda->mVoltMin)) / 10000L );

 /* printf("mVolt: %4d   code: %3X\n", mVolt, digCode); */

 outportb(dda->dac0L+(nDac*2),  digCode & 0x00FF);
 outportb(dda->dac0H+(nDac*2), (digCode & 0xFF00) >> 8);
}



/**********************************************************
***                                                     ***
***                  Gestione Porte I/O                 ***
***                                                     ***
**********************************************************/

void DDASetModePort(DDATypeRegs *dda, byte modePortA, byte modePortB, byte modePortC)
{
 byte mode;

 mode  = 0x80;

 if (modePortA == DDA_PORT_INPUT) mode |= 0x10;
 if (modePortB == DDA_PORT_INPUT) mode |= 0x02;
 if (modePortC == DDA_PORT_INPUT) mode |= 0x09;

 dda->bitsPortA = 0;
 dda->bitsPortB = 0;
 dda->bitsPortC = 0;
 outportb(dda->RegIOMode, mode);
}

void DDAWritePortA(DDATypeRegs *dda, byte data)
{
 dda->bitsPortA = data;
 outportb(dda->RegIOA, dda->bitsPortA);
}

void DDAWritePortB(DDATypeRegs *dda, byte data)
{
 dda->bitsPortB = data;
 outportb(dda->RegIOB, dda->bitsPortB);
}

void DDAWritePortC(DDATypeRegs *dda, byte data)
{
 dda->bitsPortC = data;
 outportb(dda->RegIOC, dda->bitsPortC);
}

byte DDAReadPortA(DDATypeRegs *dda)
{
 return (inportb(dda->RegIOA));
}

byte DDAReadPortB(DDATypeRegs *dda)
{
 return (inportb(dda->RegIOB));
}

byte DDAReadPortC(DDATypeRegs *dda)
{
 return (inportb(dda->RegIOC));
}

void DDAWriteBitPortA(DDATypeRegs *dda, byte bit, byte status)
{
 if (status == ON) dda->bitsPortA |= (1 << bit);
	      else dda->bitsPortA &= ~(1 << bit);

 outportb(dda->RegIOA, dda->bitsPortA);
}

void DDAWriteBitPortB(DDATypeRegs *dda, byte bit, byte status)
{
 if (status == ON) dda->bitsPortB |= (1 << bit);
	      else dda->bitsPortB &= ~(1 << bit);

 outportb(dda->RegIOB, dda->bitsPortB);
}

void DDAWriteBitPortC(DDATypeRegs *dda, byte bit, byte status)
{
 if (status == ON) dda->bitsPortC |= (1 << bit);
	      else dda->bitsPortC &= ~(1 << bit);

 outportb(dda->RegIOC, dda->bitsPortC);
}

byte DDAReadBitPortA(DDATypeRegs *dda, byte bit)
{
 byte data;

 data = inportb(dda->RegIOA);
 return( (data >> bit) & 1);
}

byte DDAReadBitPortB(DDATypeRegs *dda, byte bit)
{
 byte data;

 data = inportb(dda->RegIOB);
 return( (data >> bit) & 1);
}

byte DDAReadBitPortC(DDATypeRegs *dda, byte bit)
{
 byte data;

 data = inportb(dda->RegIOC);
 return( (data >> bit) & 1);
}
